This is a plain text file used to describe the app should be shown as redundant.
